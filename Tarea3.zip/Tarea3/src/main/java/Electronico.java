public class Electronico extends Producto {
   
    public Electronico(String nombre, double precio, int cantidad) {
        super(nombre, precio, cantidad);
    }

   
    @Override
    public void agregarCantidad(int cantidad) {
        this.cantidad += cantidad;
        System.out.println("Se han agregado " + cantidad + " unidades de " + nombre + " al inventario.");
    }

    @Override
    public void vender(int cantidad) {
        if (this.cantidad >= cantidad) {
            this.cantidad -= cantidad;
            System.out.println("Se han vendido " + cantidad + " unidades de " + nombre + ".");
        } else {
            System.out.println("No hay suficiente cantidad de " + nombre + " para vender.");
        }
    }
}