/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarea3;

/**
 *
 * @author jdrat
 */
public class Tarea3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
