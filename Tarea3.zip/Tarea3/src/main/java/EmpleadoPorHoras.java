public class EmpleadoPorHoras extends Empleado {
    private int horasTrabajadas;
    private double tarifaPorHora;

   
    public EmpleadoPorHoras(String nombre, String id, double salarioBase, int horasTrabajadas, double tarifaPorHora) {
        super(nombre, id, salarioBase);
        this.horasTrabajadas = horasTrabajadas;
        this.tarifaPorHora = tarifaPorHora;
    }

  
    @Override
    public double calcularSalario() {
        return horasTrabajadas * tarifaPorHora;
    }
}