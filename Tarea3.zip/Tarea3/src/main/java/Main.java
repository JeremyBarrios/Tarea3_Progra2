public class Main {
    public static void main(String[] args) {
        // Prueba de la clase Libro
        Libro libro = new Libro("El Quijote", "Miguel de Cervantes");
        libro.consultarDisponibilidad();
        libro.prestar();
        libro.consultarDisponibilidad();
        libro.devolver();
        libro.consultarDisponibilidad();
        
        // Prueba de la clase Electronico
        Electronico telefono = new Electronico("Smartphone", 299.99, 10);
        telefono.consultarInventario();
        telefono.vender(3);
        telefono.consultarInventario();
        telefono.agregarCantidad(5);
        telefono.consultarInventario();
        
        // Prueba de la clase EmpleadoAsalariado
        Empleado asalariado = new EmpleadoAsalariado("Juan", "E001", 1500.00);
        asalariado.mostrarInformacion();
        System.out.println("Salario: " + asalariado.calcularSalario());

        // Prueba de la clase EmpleadoPorHoras
        Empleado porHoras = new EmpleadoPorHoras("María", "E002", 0, 40, 15.00);
        porHoras.mostrarInformacion();
        System.out.println("Salario: " + porHoras.calcularSalario());
    }
}
