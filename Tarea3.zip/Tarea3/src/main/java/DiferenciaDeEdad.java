import java.util.Scanner;

public class DiferenciaDeEdad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.print("Ingrese el año de nacimiento de la primera persona: ");
        int añoPersona1 = scanner.nextInt();
        
        System.out.print("Ingrese el año de nacimiento de la segunda persona: ");
        int añoPersona2 = scanner.nextInt();
        
        
        int diferencia = Math.abs(añoPersona1 - añoPersona2);
        
        
        if (añoPersona1 < añoPersona2) {
            System.out.println("La primera persona es mayor por " + diferencia + " años.");
        } else if (añoPersona1 > añoPersona2) {
            System.out.println("La segunda persona es mayor por " + diferencia + " años.");
        } else {
            System.out.println("Ambas personas tienen la misma edad.");
        }
        
      
        scanner.close();
    }
}
