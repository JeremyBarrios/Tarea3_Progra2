public class Libro {
    private String titulo;
    private String autor;
    private boolean disponible;
    
    public Libro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = true;
        
         }
    
        public void prestar(){
            if (disponible) {
                disponible = false;
                System.out.println("El libro '" + titulo + "' a sido prestado");
            } else {
                System.out.println("El libro '" + titulo + "' no esta disponible para prestamo");
            }
   
        }
        
public void devolver() {
        disponible = true;
        System.out.println("El libro '" + titulo + "' ha sido devuelto y está disponible.");
    }

public void consultarDisponibilidad() {
        if (disponible) {
            System.out.println("El libro '" + titulo + "' está disponible para préstamo.");
        } else {
            System.out.println("El libro '" + titulo + "' no está disponible para préstamo.");
        }
    }
            
}
        
